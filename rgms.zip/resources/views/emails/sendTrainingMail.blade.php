<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
 
   
    <p>Training Mails</p>
    <h2>Its  is a fantatic mail</h2>
</body>
</html>


