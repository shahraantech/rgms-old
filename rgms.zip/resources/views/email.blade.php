



Hello <strong>{{ $name }}</strong>,
<h2>Welcome in Linguistics</h2>
<p>{{$body}}</p>
