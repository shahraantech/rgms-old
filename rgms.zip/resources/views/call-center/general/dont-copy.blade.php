
    <script type="text/javascript">
        $(document).ready(function() {
            $('body').bind('cut copy', function(event) {
                event.preventDefault();
            });
        });
    </script>





