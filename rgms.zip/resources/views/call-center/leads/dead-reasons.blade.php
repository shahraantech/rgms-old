
                                    <div class="form-group">

                                        <select name="dead_reason" id="" class="form-control">
                                            <option value="">Dead Reason</option>
                                            <option value="1">Politics Reason</option>
                                            <option value="2">Economic Reason</option>
                                            <option value="3">Out of Budget</option>
                                            <option value="4">Not Interested In Properties</option>
                                            <option value="5">Already Invested Other </option>

                                        </select>
                                    </div>
