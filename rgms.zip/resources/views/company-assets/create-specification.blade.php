@extends('setup.master')
@section('content')



    <div class="page-wrapper">
        <!-- Page Content -->
        <div class="content container-fluid">
            <!-- Page Header -->
            <div class="page-header my-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title bold-heading">Create Specification</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ url('/') }}">Dashboard</a></li>
                            <li class="breadcrumb-item active">Create Specification</li>
                        </ul>
                    </div>
                    <div class="col-auto float-right ml-auto">
                        <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_supplier"
                            title="Add Supplier"><i class="fa fa-plus"></i></a>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered mt-5 table-hover table-striped">
                        <thead>
                            <tr class="bold-tr">
                                <th># </th>
                                <th>Asset</th>
                                <th>Specification</th>
                                <th>Created At </th>
                                <th>Action </th>
                            </tr>
                        </thead>
                        <tbody id="supplierTable">
                            @isset($specs)
                                @foreach ($specs as $key => $spec)
                                    <tr>
                                        <td>{{ $key + 1 }}</td>
                                        <td>{{ $spec->speci->title }}</td>
                                        <td>{{ $spec->specification }}</td>
                                        <td>{{ $spec->created_at }}</td>
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a href="#" class="action-icon"
                                                    data-toggle="dropdown"aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right" style="">
                                                    <a class="dropdown-item btn_edit_specification" href="javascript:void(0)"
                                                        data="{{ $spec->id }}"><i class="fa fa-pencil"></i>Edit</a>
                                                    <a class="dropdown-item btn_delete_specification" href="javascript:void(0)"
                                                        data="{{ $spec->id }}"><i class="fa fa-pencil"></i>Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            @endisset
                        </tbody>
                    </table>

                </div>
            </div>
            <!-- /Page Content -->
        </div>

        <!-- Add Ticket Modal -->
        <div id="add_supplier" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close btn-dismiss" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h5 class="modal-title">Add Specification</h5>
                    </div>
                    <div class="modal-body">
                        <form method="POST" action="{{ url('store-specification') }}" class="needs-validation" novalidate
                            id="specificationForm">
                            @csrf
                            <table class="table table-bordered mt-5 table-style">

                                <label for="">Assets</label>
                                <select class="form-control" name="asset_id" required>
                                    <option value="">Choose Assets</option>
                                    @isset($assets)
                                        @foreach ($assets as $asset)
                                            <option value="{{ $asset->id }}">{{ $asset->title }}</option>
                                        @endforeach
                                    @endisset
                                    <div class="invalid-feedback">
                                        Please choose source .
                                    </div>
                                </select>

                                <thead>
                                    <tr>
                                        <th>Specification <span class="text-danger">*</span></th>
                                    </tr>
                                </thead>
                                <tbody id="tblPurchase">
                                    <tr>
                                        <td>
                                            <input type="text" name="specification[]" class="form-control"
                                                placeholder="Specification" required>
                                        </td>

                                        <td class="text-center"><button type="button" class="btn-success mt-2"
                                                id="addNewRow"><i class="fa fa-plus"></i></button>
                                        </td>
                                    </tr>
                                </tbody>

                            </table>

                            <div class="submit-section">
                                <button type="submit" class="btn btn-primary btn-submit btn_specification">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Add Ticket Modal -->


        <script type="text/javascript">
            $(function() {
                $('#addNewRow').on('click', function() {
                    var tr = $("#dvOrders").find("Table").find("TR:has(td)").clone();
                    console.log(tr);
                    $("#tblPurchase").append(tr);
                });
            });
        </script>

        <div id="dvOrders" style="display:none">
            <table class="table table-bordered mt-5 table-style">
                <thead>
                    <tr>
                        <th>Specification <span class="text-danger">*</span></th>
                    </tr>
                </thead>
                <tbody id="tblPurchase">
                    <tr>
                        <td>
                            <input type="text" name="specification[]" class="form-control" placeholder="specification"
                                required>
                        </td>

                        <td style="color:red;cursor: pointer" class="delete-row text-center" title="Remove"><i
                                class="fa fa-trash"></i>
                        </td>
                    </tr>
                </tbody>

            </table>
        </div>



        <!-- Edit Ticket Modal -->
        <div id="edit_variation_modal" class="modal custom-modal fade" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Edit Specification</h5>
                        <button type="button" class="close btn-dismiss" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form method="POST" action="{{ url('update-specification') }}" class="needs-validation" novalidate
                            id="specificationEditForm">
                            <input type="hidden" name="specification_id">
                            @csrf
                            <div class="row">

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Asset</label>
                                        <select name="asset_id" class="select">
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Specificaiton</label>
                                        <input class="form-control" type="text" name="specification"
                                            placeholder="Specification" required>
                                    </div>
                                </div>


                            </div>

                            <div class="submit-section">
                                <button class="btn btn-primary btn-submit btn_specification_update"
                                    type="submit">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Edit Ticket Modal -->

        <script>
            $(document).ready(function() {
                var rowIdx = 0;
                // jQuery button click event to remove a row.
                $('#tblPurchase').on('click', '.delete-row', function() {

                    // Getting all the rows next to the row
                    // containing the clicked button
                    var child = $(this).closest('tr').nextAll();

                    // Iterating across all the rows
                    // obtained to change the index
                    child.each(function() {

                        // Getting <tr> id.
                        var id = $(this).attr('id');

                        // Getting the <p> inside the .row-index class.
                        var idx = $(this).children('.row-index').children('p');

                        // Gets the row number from <tr> id.
                        var dig = parseInt(id.substring(1));

                        // Modifying row index.
                        idx.html(`Row ${dig - 1}`);

                        // Modifying row id.
                        $(this).attr('id', `R${dig - 1}`);
                    });

                    // Removing the current row.
                    $(this).closest('tr').remove();

                    // Decreasing total number of rows by 1.
                    rowIdx--;
                });

            });
        </script>

        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <!-- CDN for Sweet Alert -->
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            $(document).ready(function() {

                toastr.options.timeOut = 3000;
                @if (Session::has('error'))
                    toastr.error('{{ Session::get('error') }}');
                @elseif(Session::has('success'))
                    toastr.success('{{ Session::get('success') }}');
                @endif

                //Edit Level 1
                $('#supplierTable').on('click', '.btn_edit_specification', function(e) {
                    e.preventDefault();

                    var id = $(this).attr('data');

                    $('#edit_variation_modal').modal('show');

                    $.ajax({

                        type: 'ajax',
                        method: 'get',
                        url: '{{ url('edit-specification') }}',
                        data: {
                            id: id
                        },
                        async: false,
                        dataType: 'json',
                        success: function(data) {

                            $('input[name=specification_id]').val(data.spec.id);
                            $('input[name=specification]').val(data.spec.specification);
                            $.each(data.asset, function(key, asset) {

                                $('select[name="asset_id"]')
                                    .append(
                                        `<option value="${asset.id}" ${asset.id == data.spec.asset_id ? 'selected' : ''}>${asset.title}</option>`
                                    )
                            });
                        },

                        error: function() {

                            toastr.error('something went wrong');

                        }

                    });

                });


                // Delete Level 3
                $('#supplierTable').on('click', '.btn_delete_specification', function(e) {
                    e.preventDefault();

                    var id = $(this).attr('data');

                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to Delete this Data!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                type: "GET",
                                url: "{{ url('delete-specification') }}",
                                data: {
                                    id: id
                                },
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                dataType: "json",
                                success: function(response) {

                                    toastr.success(response.message);
                                    setTimeout(() => {
                                        window.location.reload();
                                    }, 2000);
                                }
                            });
                        }
                    })

                });

            });


            $('.btn_specification').on('click', function() {
                $(".btn_specification").prop("disabled", true);
                $(".btn_specification").html("Please wait...");
                $('#specificationForm').submit();
            });

            $('.btn_specification_update').on('click', function() {
                $(".btn_specification_update").prop("disabled", true);
                $(".btn_specification_update").html("Please wait...");
                $('#specificationEditForm').submit();
            });

        </script>
    @endsection
